<?php

$servername = "192.168.100.101";
$port = "3306";
$username = "root";
$password = "";
$dbname = "ingenieria";

$conn = new MySQLi($servername, $username, $password, $dbname);

// Error de conexión
if ($conn->connect_error) {
    die("Error de conexion: " . $conn->connect_error);
}

$sql = "SELECT alumnos.legajo 'legajo', 
               alumnos.apellido 'apellido', 
               alumnos.nombres 'nombre',
               modulos.nom_modulo 'materia', 
               notas.nota 'nota'
        FROM alumnos, 
             modulos, 
             notas 
        WHERE alumnos.legajo = notas.legajo 
          AND modulos.cod_modulo = notas.cod_modulo;";

if ($result = $conn->query($sql)) {
    while ($row = $result->fetch_assoc()) {
        echo "legajo: " . $row["legajo"] . " - Nombre: " . $row["nombre"] . " " . $row["apellido"] . " | " . $row["materia"] . " ---> Nota: " . $row["nota"] . "<br>";
    }
} else {
    echo "Error ejecutando la consulta: " . $conn->error;
}

$conn->close();
?>
